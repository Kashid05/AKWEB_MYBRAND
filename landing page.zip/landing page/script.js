

    setTimeout(()=>{
        let sloganLine = document.getElementById('slogan');
        sloganLine.innerHTML = "Capturing Moments of Life in Pixel";
    },10000)    


    setTimeout(()=>{
        let changeBgColor = document.getElementById('about');
        changeBgColor.style.backgroundColor = 'lightgreen';
    },5500)
    setTimeout(()=>{
        let changeBgColor = document.getElementById('gallery');
        changeBgColor.style.backgroundColor = 'lightblue';
    },5500)